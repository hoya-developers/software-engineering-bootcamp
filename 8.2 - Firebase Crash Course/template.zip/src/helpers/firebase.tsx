import { initializeApp } from "firebase/app";
import "firebase/auth";

const firebaseConfig = {
  //Firebase config from the console
};

const app = initializeApp(firebaseConfig);

export const auth = app.auth();

export function signUp(email, password) {
  //do something
}

export function login(email, password) {
  //do something
}
