import React, { useState } from "react";

const Login = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = (e) => {
    e.preventDefault();
    console.log("Login");
  };

  const handleSignUp = (e) => {
    e.preventDefault();
    console.log("Sign up");
  };

  return (
    <form className="login-form">
      Log in
      <input
        type="text"
        placeholder="Username"
        onChange={(e) => setUsername(e.target.value)}
      />
      <input
        type="password"
        placeholder="Password"
        onChange={(e) => setPassword(e.target.value)}
      />
      <button type="button" onClick={handleLogin}>
        Log in
      </button>
      <button type="button" onClick={handleSignUp}>
        Sign up
      </button>
    </form>
  );
};

export default Login;
