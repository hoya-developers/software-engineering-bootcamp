import "./App.css";
import Login from "./screens/login.tsx";
import { auth } from "./helpers/firebase.tsx";

function App() {
  return (
    <div className="App">
      <Login />
      <div>Current user ID:</div>
    </div>
  );
}

export default App;
